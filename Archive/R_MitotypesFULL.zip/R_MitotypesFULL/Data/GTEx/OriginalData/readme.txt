GTEx dataset version 8: 
- Download from https://www.gtexportal.org/home/downloads/adult-gtex/bulk_tissue_expression
- No protected data needed
- Place all files (gene_tpm, sample attributes, subject phenotypes, gene read, gene_median_tpm) in the folder "Data/GTEx/OriginalData" and extract the .gz files in the same folder.
