Human Protein Atlas dataset version 21.0: 
- Download from https://v21.proteinatlas.org/about/download. 
- Important note: the publicly available version 21.1 no longer includes the olfactory bulb.  For robustness analysis, we re-ran the code without the olfactory bulb, and found no major impact on the results, but the dataset only has 54 tissues. Some stats might be slightly different. 
- Place "rn_human_tissue_consensus.tsv" in the "Data/HumanProteinAtlas/OriginalData" folder.
