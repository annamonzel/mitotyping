Mouse and human MitoCarta3.0 datasets: 
- Download from https://www.broadinstitute.org/mitocarta
- Place "HumanMitoCarta3_0.xls" and "MouseMitoCarta3_0.xls" in the "Data/MitoCarta/OriginalData" folder.
